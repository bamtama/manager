import {remoteLoad} from './remoteLoad'
import {ajax} from './common'
/**
 * 接口导出
 */
export {
  remoteLoad ,
  ajax
}
