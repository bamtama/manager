import Vconsole from "vconsole"

export default {
  install(Vue){
    const vConsole = new Vconsole()
  }
}
// export default vConsole