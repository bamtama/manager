'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_HOST: '""'
}
